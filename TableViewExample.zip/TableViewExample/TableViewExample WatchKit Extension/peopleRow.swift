//
//  peopleRow.swift
//  TableViewExample WatchKit Extension
//
//  Created by MacStudent on 2019-06-20.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import WatchKit

class peopleRow: NSObject {

    @IBOutlet weak var PersonLable: WKInterfaceLabel!
    
    
}
