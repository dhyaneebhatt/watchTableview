//
//  InterfaceController.swift
//  pokemoneImage WatchKit Extension
//
//  Created by MacStudent on 2019-06-20.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {

    @IBOutlet weak var PokemonTable: WKInterfaceTable!
    
    //MARK: Table data source
    let pokemon:[String] = ["Alay", "Dhyanee", "Shivam", "Saloni"]

    let images:[String] = ["001", "002", "003", "004"]

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        
        self.PokemonTable.setNumberOfRows(self.pokemon.count, withRowType:"myRaw")
        
        for (index, name) in self.pokemon.enumerated()
        {
            let row = self.PokemonTable.rowController(at: index) as! PokemonRowController
            row.PokemonNameLabel.setText(name)
        }
        
        for (index, imageName) in self.images.enumerated()
        {
            let row = self.PokemonTable.rowController(at: index) as! PokemonRowController
            row.PokemonImage.setImageNamed(imageName)
        }
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
